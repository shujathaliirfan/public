<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
$consult_name=$_POST['consult_name'];
$consult_email=$_POST['email'];
$consult_location=$_POST['consult_location'];
$date=$_POST['date'];
$primaryexpertise=$_POST['primaryexpertise'];
$other_prim_expert=$_POST['other_prim_expert'];
$codediscipline=$_POST['codediscipline'];
$other_codediscipline=$_POST['other_codediscipline'];
$coredomain=$_POST['coredomain'];
$other_coredomain=$_POST['other_coredomain'];
$total_experience=$_POST['total_experience'];
$relevant_experience=$_POST['relevant_experience'];
$summary_experience=$_POST['summary_experience'];
$curent_status=$_POST['curent_status'];
$other_curent_status=$_POST['other_curent_status'];
$type_workintrest=$_POST['type_workinterest'];
$other_wrkintrest=isset($_POST['other_wrkintrest']) ? $_POST['other_wrkintrest'] : '';
$comments=$_POST['comments'];
$queries_any=$_POST['queries_any'];
$expectations=$_POST['expectations'];

$message = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="m_5275377665128817231bodyTable" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%;background-color:#e9eaec">
        <tbody><tr>
            <td align="center" valign="top" id="m_5275377665128817231bodyCell" style="height:100%;margin:0;padding:50px 50px;width:100%">
               

                <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_5275377665128817231templateContainer" style="border-collapse:collapse;border:0;max-width:600px!important">
                                            <tbody><tr>
                        <td valign="top" id="m_5275377665128817231templateBody" style="background-color:#ffffff;border-top:0;border:1px solid #c1c1c1;padding-top:0;padding-bottom:0px">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_5275377665128817231mcnTextBlock" style="min-width:100%;border-collapse:collapse">
                                <tbody class="m_5275377665128817231mcnTextBlockOuter">
                                    <tr>
                                        <td valign="top" class="m_5275377665128817231mcnTextBlockInner">
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_5275377665128817231mcnTextContentContainer">
                                                <tbody>
                                                    <tr>
                                                        <td valign="top" style="padding-top:30px;padding-right:30px;padding-bottom:20px;padding-left:30px" class="m_5275377665128817231mcnTextContent">
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Consultant Name </strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$consult_name.'</td>
    </tr>
    </tbody>
    </table>
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>consultant Email </strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$consult_name.'</td>
    </tr>
    </tbody>
    </table>
    
<table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>consultant Location </strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$consult_location.'</td>
    </tr>
    </tbody>
    </table>
<table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Date</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$date.'</td>
    </tr>
    </tbody>
    </table>
<table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Primary Expertise</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px">';
        foreach($primaryexpertise as $primary)
        {
            if($primary=="Others")
            {
                $message.=$other_prim_expert;   
            }
            else
            {
                $message.="<ul><li>".$primary."</li></ul>"; 
            }
        }
    $message.='</td>
    
    
    
    </td>
    </tr>
    </tbody>
    </table>

<table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;    margin: 0 28px;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Code Discipline </strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">';
        foreach($codediscipline as $code)
        {
            if($code=="Others")
            {
                $message.= $other_codediscipline;   
            }
            else
            {
                $message.="<ul><li>".$code."</li></ul>"; 
            }
        }
    $message.='</td>
    
    
    
  
    </tr>
    </tbody>
    </table><table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;     margin: 0 28px;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Core Domain</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">';
        foreach($coredomain as $core)
        {
            if($core=="Others")
            {
             $message.= $other_coredomain;   
            }
            else
            {
                $message.="<ul><li>".$core."</li></ul>"; 
            }
        }
    $message.='</td>
    </tr>
    </tbody>
    </table>

<table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;    margin: 0 28px;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Total Experience</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$total_experience.'</td>
    </tr>
    </tbody>
    </table>

<table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;    margin: 0 28px; width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Relevant Experience</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$relevant_experience.'</td>
    </tr>
    </tbody>
    </table>


<table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;    margin: 0 28px; width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Summary Experience</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$summary_experience.'</td>
    </tr>
    </tbody>
    </table>



<table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;    margin: 0 28px; width:100%">
    <tbody>
  <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Current Status</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">';
        foreach($curent_status as $cstatus)
        {
            if($cstatus=="Others")
            {
             $message.= $other_curent_status;   
            }
            else
            {
                $message.="<ul><li>".$cstatus."</li></ul>"; 
            }
        }
    $message.='</td>
    </tr>
    </tbody>
    </table><table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;    margin: 0 28px; width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Type of Work Interested</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">';
        foreach($type_workintrest as $work)
        {
            if($work=="Others")
            {
             $message.= $other_wrkintrest;   
            }
            else
            {
                $message.="<ul><li>".$work."</li></ul>"; 
            }
        }
    $message.='</td>
    </tr>
    </tbody>
    </table><table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;    margin: 0 28px; width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Comments</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$comments.'</td>
    </tr>
    </tbody>
    </table>
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;    margin: 0 28px; width:100%">
        <tbody>
        <tr>
        <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Queries if any</strong></td>
        </tr>
        <tr>
        <td style="color:#555555;padding-top:3px;padding-bottom:20px; text-align:justify";><div style="text-align:justify;">'.$queries_any.'</div></td>
        </tr>
        </tbody>
        </table>
        <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;    margin: 0 28px; width:100%">
        <tbody>
        <tr>
        <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Expectations</strong></td>
        </tr>
        <tr>
        <td style="color:#555555;padding-top:3px;padding-bottom:20px; text-align:justify";><div style="text-align:justify;">'.$expectations.'</div></td>
        </tr>
        </tbody>
        </table>

   
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" id="m_5275377665128817231templateFooter" style="background-color:#e9eaec;border-top:0;border-bottom:0;padding-top:12px;padding-bottom:12px">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_5275377665128817231mcnTextBlock" style="min-width:100%;border-collapse:collapse">
                                <tbody class="m_5275377665128817231mcnTextBlockOuter">
                                    <tr>
                                        <td valign="top" class="m_5275377665128817231mcnTextBlockInner">
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_5275377665128817231mcnTextContentContainer">
                                                <tbody>
                                                    <tr>
                                                       
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody></table>
               

                </td>
            </tr>
        </tbody></table>
</body>
</html>';







        $msg="<head><style>
        td{
        padding: 10px;
        border: 1px solid #000;
        color: #000;
        }
        table{
        border-collapse: collapse;
        }
        tr td:first-child {
        background: #94001b;
        color: #fff;
        }
        ul{
        padding-left: 0;
        margin: 0;
        padding-bottom: 10px;
        }
        </style>
        </head>
        <table border='1' width='70%'>
        <tr>
        <td style='background: #94001b;color: #fff;'>Consultant Name</td>
        <td>$consult_name</td>
        </tr>
        
        <tr>
        <td style='background: #94001b;color: #fff;'>consultant Email</td>
        <td>$consult_email</td>
        </tr>
        <tr>
        <td style='background: #94001b;color: #fff;'>consultant Location</td>
        <td>$consult_location</td>
        </tr>
        
        <tr>
        <td style='background: #94001b;color: #fff;'>Date</td>
        <td>$date</td>
        </tr>";
        $msg.="<tr>
        <td style='background: #94001b;color: #fff;'>Primary Expertise</td><td>";
        foreach($primaryexpertise as $primary)
        {
            if($primary=="Others")
            {
                $msg.=$other_prim_expert;   
            }
            else
            {
                $msg.="<ul><li>".$primary."</li></ul>"; 
            }
        }
        $msg.="</td></tr>";
        $msg.="<tr><td style='background: #94001b;color: #fff;'>Code Discipline</td><td>";
        foreach($codediscipline as $code)
        {
            if($code=="Others")
            {
                $msg.= $other_codediscipline;   
            }
            else
            {
                $msg.="<ul><li>".$code."</li></ul>"; 
            }
        }
        $msg.="</td></tr>";
        $msg.="<tr><td style='background: #94001b;color: #fff;'>Core Domain</td><td>";
        foreach($coredomain as $core)
        {
            if($core=="Others")
            {
             $msg.= $other_coredomain;   
            }
            else
            {
                $msg.="<ul><li>".$core."</li></ul>"; 
            }
        }
        $msg.="</td></tr>";
        $msg.="<tr> <td style='background: #94001b;color: #fff;'>Total Experience</td><td>$total_experience</td></tr>
        <tr><td style='background: #94001b;color: #fff;'>Relevant Experience</td><td>$relevant_experience</td></tr>
        <tr><td style='background: #94001b;color: #fff;'>Summary Experience</td><td>$summary_experience</td></tr>";
        $msg.="<tr>
        <td style='background: #94001b;color: #fff;'>Current Status</td><td>";
        
        foreach($curent_status as $cstatus)
        {
            if($cstatus=="Others")
            {
             $msg.= $other_curent_status;   
            }
            else
            {
                $msg.="<ul><li>".$cstatus."</li></ul>"; 
            }
        }
        $msg.="</td></tr>";
        $msg.="<tr><td style='background: #94001b;color: #fff;'>Type of Work Interested</td><td>";
        foreach($type_workintrest as $work)
        {
            if($work=="Others")
            {
             $msg.= $other_wrkintrest;   
            }
            else
            {
                $msg.="<ul><li>".$work."</li></ul>"; 
            }
        }
        $msg.="</td></tr>";
        $msg.="<tr><td style='background: #94001b;color: #fff;'>Comments</td><td>$comments</td></tr>
        <tr><td style='background: #94001b;color: #fff;'>Queries if any</td><td>$queries_any</td></tr>
        <tr><td style='background: #94001b; color: #fff;'>Expectations</td><td>$expectations</td></tr>";
       
        $mail = new PHPMailer(true);
        $mail->SMTPDebug =0;                    
        $mail->isSMTP();                                          
        $mail->Host       = 'us2.smtp.mailostbox.com';                    
        $mail->SMTPAuth   = true;                              
        $mail->Username   = 'support@drillesdesk.com';                    
        $mail->Password   = 'X(*Pgmy4';                              
        $mail->Port       = 587;                                    
    $mail->From = "support@drillesdsk.com";
        //Recipients
        $mail->AddAddress("contact@iwellsc.com", "Drillersdesk");
        // $mail->AddAddress("irfan@xmediasolution.com", "Drillersdesk");
        $mail->SetFrom("support@drillersesk.com", "Drillersdesk");
        // $mail->addCC('projects@xmediasolution.com');
        // $mail->addBCC('ajithkumar@xmediasolution.com');
        $mail->Subject = "Enquiry from drillersdesk consultant";
        // $mail->SMTPSecure = "tls";  
        // Content
        $mail->isHTML(true);                                
        // $mail->Subject  = "Contact Us";
        $mail->msgHTML($message);
    
        if($mail->send())
        {
             echo "<script>

        window.location = 'https://drillersdesk.com/';
                               alert('Mail sent successfully');

         </script>";
        }
        else
        {
            echo 'fail';
        }

