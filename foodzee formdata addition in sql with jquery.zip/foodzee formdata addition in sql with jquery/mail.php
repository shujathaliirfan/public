<?php 

$servername = "localhost";
$username = "fodezee_new";
$password = "che1";
$dbname = "foodeodezee_new";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// echo "Connected successfully";


 


require 'PHPMailer_master/src/Exception.php';
require 'PHPMailer_master/src/PHPMailer.php';
require 'PHPMailer_master/src/SMTP.php';
// echo 'flkgj';
date_default_timezone_set('Asia/Kolkata');
$name = $_POST['name'];
$mobile = $_POST['m_number'];
$email = $_POST['email'];
// $prefer =  $lan;
$quantity= $_POST['quantity'];
$EMI = $_POST['emi'];
$address = $_POST['address'];

$date = date('Y/m/d');
$time = date("h:i:sa");
$prefer = implode(',', $_POST['check']);


// if($_POST['check1'])
// {

// $lan=$_POST['check1'];
// }

// if($_POST['check2'])
// {

// $lan=$_POST['check1'].$_POST['check2'];
// }

// if($_POST['check3'])
// {

// $lan=$_POST['check1'].$_POST['check2'].$_POST['check3'];
// }


$mail = new PHPMailer\PHPMailer\PHPMailer();
 $mail->isSMTP();                            // Set mailer to use SMTP
    $mail->Host      = 'mailion.com';        // Specify main and backup SMTP servers
    $mail->SMTPAuth  = true;                    // Enable SMTP authentication
    $mail->CharSet   = "UTF-8";
    $mail->SMTPDebug = 0;                       // Enable verbose debug output
    $mail->isHTML(true);                        // Set email format to HTML
    // $mail->name = $_POST['name'];                       
    $mail->Mail = $_POST['mail'];                       
    // $mail->number =  $_POST['number'];                       
    $mail->subject =  $_POST['subject'];                      
    $mail->message =  $_POST['message'];
    
    
    $mail->Username = 'info@vidhoundation.com';                    // SMTP username
    $mail->Password ='chennai01';                     // SMTP password
    
    //$mail->SMTPAutoTLS    = false;
    $mail->SMTPSecure   = 'ssl';                // Enable TLS encryption, `ssl` also accepted
    $mail->Port         = 465;                  // TCP port to connect to

    $mail->setFrom('irfan@xmeion.com','foodezee');           // Mail Form
    $mail->addAddress('irfan@solution.com');             // Mail Form
    // $mail->addAddress('sri@emporesllc.com');          // Name is optional

    $mail->Subject = "Empores Estimate Quote";
    $mail->Body    = '<html>
<head>
  <title>Estimate Quote</title>
  <style>
  th {
    background: #1C9B48;
    color: #fff;
    padding: 5px 10px;
}
td {
    padding: 0 20px;
    background: #f0f0f0;
}
  th, td {text-align:left; }
  </style>
</head>
<body>
 <table>
 <tr>
 <th> Company Name</th>
 <td>' . $name . '</td>
 </tr>
 <tr>
 <th> Contact Name</th>
 <td>' . $mobile . '</td>
 </tr>
 <tr>
 <th> Designation</th>
 <td>' . $email . '</td>
 </tr>
 <tr>
 <th> Address</th>
 <td>' . $prefer . '</td>
 </tr>
 <tr>
 <th> Phone</th>
 <td>' . $quantity . '</td>
 </tr>
 <tr>
 <th> Email</th>
 <td>' . $EMI . '</td>
 </tr>
 <tr>
 <th> Annual Energybill</th>
 <td>' . $address . '</td>
 </tr>
 
 </table>
</body>
</html>';
    
  if(!$mail->Send()) {
        $error = 'Mail error: '.$mail->ErrorInfo;
        // echo 'error';
    } else {
        $error = 'Message sent!';
        // echo 'message sent';
    }
    
    
    // database insertion
    
    $sql = "INSERT INTO form_data (id, name, mobile, email ,	prefer, quantity,	emi, address, date	) VALUES (NULL, ' $name ', ' $mobile ', ' $email ', ' $prefer ', ' $quantity ', ' $EMI ', '  $address ', '$date - $time' )";
    
    if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
    } else {
      echo "Error: <br>" . $conn->error;
    }

    
    
    
    

?>


