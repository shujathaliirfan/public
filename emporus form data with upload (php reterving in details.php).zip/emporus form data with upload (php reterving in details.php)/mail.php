<?php 

$servername = "localhost";
$username = "vidhai_empores";
$password = "chennai01";
$dbname = "vidhai_empores";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// echo "Connected successfully";


require 'PHPMailer_master/src/Exception.php';
require 'PHPMailer_master/src/PHPMailer.php';
require 'PHPMailer_master/src/SMTP.php';
// echo 'flkgj';
date_default_timezone_set('Asia/Kolkata');
$company_name = $_POST['company_name'];
$contact_name = $_POST['contact_name'];
$designation = $_POST['designation'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$annualenergybill = $_POST['annualenergybill'];
$peakdemand = $_POST['peakdemand'];
$contractdemand = $_POST['contractdemand'];
$uploadenergybill = $_POST['uploadenergybill'];
$date = date('Y/m/d');
$time = date("h:i:sa");

print_r($_POST);

if(isset($_POST)){
    $filename = $_FILES['file']['name'];
}




// $file = rand(1000,100000)."-".$_FILES['file']['name'];
$filename = $_FILES['file']['name']; 
// echo $filename;
$tempname = $_FILES["file"]["tmp_name"];     
// $folder = "images/".$filename;  

    // get the file extension
    $extension = pathinfo($filename, PATHINFO_EXTENSION);
    // echo  $extension;
    // the physical file on a temporary uploads directory on the server
    // $file = $_FILES['file']['tmp_name'];
    // $size = $_FILES['file']['size'];
    $path = "images/" . basename($filename);
    
         if (move_uploaded_file($tempname, $path)) {
            echo 'uploaded';
            
        } else {
            echo "Failed to upload file.";
        }   
            
 
 
 /* make file name in lower case */
 $new_file_name = strtolower($file);
 /* make file name in lower case */
 
 $final_file=str_replace(' ','-',$new_file_name);



$mail = new PHPMailer\PHPMailer\PHPMailer();
 $mail->isSMTP();                            // Set mailer to use SMTP
    $mail->Host      = 'mail.vidhai-foundation.com';        // Specify main and backup SMTP servers
    $mail->SMTPAuth  = true;                    // Enable SMTP authentication
    $mail->CharSet   = "UTF-8";
    $mail->SMTPDebug = 0;                       // Enable verbose debug output
    $mail->isHTML(true);                        // Set email format to HTML
    // $mail->name = $_POST['name'];                       
    $mail->Mail = $_POST['mail'];                       
    // $mail->number =  $_POST['number'];                       
    $mail->subject =  $_POST['subject'];                      
    $mail->message =  $_POST['message'];
    
    
    $mail->Username = 'info@vidhai-foundation.com';                    // SMTP username
    $mail->Password ='chennai01';                     // SMTP password
    
    //$mail->SMTPAutoTLS    = false;
    $mail->SMTPSecure   = 'ssl';                // Enable TLS encryption, `ssl` also accepted
    $mail->Port         = 465;                  // TCP port to connect to

    $mail->setFrom('murugadheebam@xmediasolution.com','Empores');           // Mail Form
    $mail->addAddress('sindhu@xmediasolution.com');             // Mail Form
    $mail->addAddress('muthu@xbs.in');             // Mail Form
    $mail->addAddress('sri@emporesllc.com');          // Name is optional

    $mail->Subject = "Empores Estimate Quote";
    $mail->Body    = '<html>
<head>
  <title>Estimate Quote</title>
  <style>
  th {
    background: #1C9B48;
    color: #fff;
    padding: 5px 10px;
}
td {
    padding: 0 20px;
    background: #f0f0f0;
}
  th, td {text-align:left; }
  </style>
</head>
<body>
 <table>
 <tr>
 <th> Company Name</th>
 <td>' . $company_name . '</td>
 </tr>
 <tr>
 <th> Contact Name</th>
 <td>' . $contact_name . '</td>
 </tr>
 <tr>
 <th> Designation</th>
 <td>' . $designation . '</td>
 </tr>
 <tr>
 <th> Address</th>
 <td>' . $address . '</td>
 </tr>
 <tr>
 <th> Phone</th>
 <td>' . $phone . '</td>
 </tr>
 <tr>
 <th> Email</th>
 <td>' . $email . '</td>
 </tr>
 <tr>
 <th> Annual Energybill</th>
 <td>' . $annualenergybill . '</td>
 </tr>
 <tr>
 <th> Peak Demand</th>
 <td>' . $peakdemand . '</td>
 </tr>
 <tr>
 <th> Contract Demand</th>
 <td>' . $contractdemand . '</td>
 </tr>
 <tr>
 <th> Peak Demand</th>
 <td>' . $company_name . '</td>
 </tr>
 <tr>
 <th> Upload Energybill</th>
 <td><a href="https://vidhai-foundation.com/empores_estimate_quote/' . $path . '">img</a></td>
 </tr>
 </table>
</body>
</html>';
    
  if(!$mail->Send()) {
        $error = 'Mail error: '.$mail->ErrorInfo;
        // echo 'error';
    } else {
        $error = 'Message sent!';
        // echo 'message sent';
    }
    
    
    // database insertion
    
    $sql = "INSERT INTO form_data (id, company_name, contact_name, designation,	address, phone,	email, annualenergybill, contractdemand, peakdemand, uploadenergybill, date	) VALUES (NULL, ' $company_name ', ' $contact_name ', ' $designation ', ' $address ', ' $phone ', ' $email ', ' $annualenergybill ', ' $peakdemand ', ' $contractdemand ', '$path', '$date - $time' )";
    
    if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
    } else {
      echo "Error: <br>" . $conn->error;
    }

    
    
    
    

?>


