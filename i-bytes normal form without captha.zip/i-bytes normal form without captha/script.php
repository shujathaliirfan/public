<?php 

require 'PHPMailer_master/src/Exception.php';
require 'PHPMailer_master/src/PHPMailer.php';
require 'PHPMailer_master/src/SMTP.php';
$name = $_POST['name'];
$email = $_POST['email'];
$number = $_POST['phone'];
$message = $_POST['message'];
$msgText = nl2br($_POST['message']);


$mail = new PHPMailer\PHPMailer\PHPMailer();

// $message = '<html>
// <head>
//   <title>Request a Quote</title>
//   <style>
//   .tbt
//   {
//       border:1px solid #000;
//       width:75%;
      
//   }
//   .tbt th
//   {
//      background-color:#7b1530;
//      text-align:left;
//      color:#fff;
//      padding:20px;
     
//   }
//   .tbt td
//   {
//     border:0px solid white;
//      background-color:#7b1530;
//      text-align:justify;
//      color:#fff;
//      padding:20px;
//   }
//   .tbt td a
//   {
//       color:#fff;
//   }
//   </style>
// </head>
// <body>
//   <table class="tbt">
//     <tr>
//       <th style="width:40%;">Name</th><td style="width:60%;">'. $name .'</td>
//     </tr>
//     <tr>
//     <th>Email</th><td>'. $email .'</td>
//     </tr>
//     <tr>
//     <th>Phone Number</th><td>'. $number .'</td>
//     </tr>
//     <tr>
//     <th>Message</th><td>'. $msgText .'</td>
//     </tr>
   
//   </table>
// </body>
// </html>';
$message = '<table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="m_5275377665128817231bodyTable" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%;background-color:#e9eaec">
        <tbody><tr>
            <td align="center" valign="top" id="m_5275377665128817231bodyCell" style="height:100%;margin:0;padding:50px 50px;width:100%">
               

                <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_5275377665128817231templateContainer" style="border-collapse:collapse;border:0;max-width:600px!important">
                                            <tbody><tr>
                        <td valign="top" id="m_5275377665128817231templateBody" style="background-color:#ffffff;border-top:0;border:1px solid #c1c1c1;padding-top:0;padding-bottom:0px">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_5275377665128817231mcnTextBlock" style="min-width:100%;border-collapse:collapse">
                                <tbody class="m_5275377665128817231mcnTextBlockOuter">
                                    <tr>
                                        <td valign="top" class="m_5275377665128817231mcnTextBlockInner">
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_5275377665128817231mcnTextContentContainer">
                                                <tbody>
                                                    <tr>
                                                        <td valign="top" style="padding-top:30px;padding-right:30px;padding-bottom:30px;padding-left:30px" class="m_5275377665128817231mcnTextContent">
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Name</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'. $name .'</td>
    </tr>
    </tbody>
    </table>
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Email</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'. $email .'</td>
    </tr>
    </tbody>
    </table><span class="im">
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Phone Number</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'. $number .'</td>
    </tr>
    </tbody>
    </table>
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;width:100%">
        <tbody>
        <tr>
        <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Message</strong></td>
        </tr>
        <tr>
        <td style="color:#555555;padding-top:3px;padding-bottom:20px text-align:justify;"><div style="text-align:justify;">'.$msgText.'</div></td>
        </tr>
        </tbody>
        </table>

   
                                                        </span></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" id="m_5275377665128817231templateFooter" style="background-color:#e9eaec;border-top:0;border-bottom:0;padding-top:12px;padding-bottom:12px">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_5275377665128817231mcnTextBlock" style="min-width:100%;border-collapse:collapse">
                                <tbody class="m_5275377665128817231mcnTextBlockOuter">
                                    <tr>
                                        <td valign="top" class="m_5275377665128817231mcnTextBlockInner">
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_5275377665128817231mcnTextContentContainer">
                                                <tbody>
                                                    <tr>
                                                       
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody></table>
               

                </td>
            </tr>
        </tbody></table>';
    // $mail = new PHPMailer();
   $mail->SMTPDebug =0;                     
    $mail->isSMTP();                             
    $mail->Host = "us2.smtp.mailostbox.com";  
    $mail->SMTPAuth   = true;                     
    $mail->Username   = 'support@drillerdesk.com';   
    $mail->Password   = 'X4';
    $mail->From = "support@drillersdesk.com";     
    $mail->Port = 587;     
  
 
    //Recipients
    $mail->FromName = "support@i-bytes.com";
    
    $mail->addAddress("contacllsmc.com", "i-bytes");
    $mail->addBCC("ajithkummediasolution.com");
    $mail->addBCC("projectmediasolution.com");
    // $mail->addReplyTo($_REQUEST['email'], $_REQUEST['name']);
    // $mail->setFrom('support@i-bytes.com','i-bytes');  

    // Content
    $mail->isHTML(true);                                
    $mail->Subject  = "Enquiry form from i-bytes.com";
    $mail->msgHTML($message);

    
   if(!$mail->Send()) {
        $error = 'Mail error: '.$mail->ErrorInfo;
        // return false;
        echo "fail";
    } else {
        $error = 'Message sent!';
        echo "success";
        // return true;
    }

?>