jQuery(document).ready(function(){
    // jQuery('#fp-nav ul ').each(element => {
    //     console.log(element);
    // });
    jQuery( "#fp-nav ul li" ).each(function( index ) {
        console.log( index + ": " + jQuery( this ).text() );
        jQuery(this).find('a > span').html('<img src="wp-content/themes/salient/img/dot-icons/dot_icon'+ index +'.svg">');
      //  jQuery(el + 'a').append('<img src="'+ index +'.jpg">');
    });

    // jQuery('#top_to_bottom').click( function() {
    //   // jQuery(document).scrollTop(jQuery(document).height()); 
    //   jQuery("html, body").animate({ 
    //     scrollTop: jQuery('html, body').get(0).scrollHeight 
    //   }, 2000); 
    // });
    $("#clickme").click(function() {
});
   $('#top_to_bottom').click(function() {
 
    $('html, body').animate({
        scrollTop: $("#prd-ibytes").offset().top
    }, 2000);
    return false;
});
    
});

// Scroll to Bottom
// function scrollSmoothToBottom (id) {
//   jQuery(scrollingElement).animate({
//     scrollTop: document.body.scrollHeight
//   }, 500);
// }
// $(document).scrollTop($(document).height()); 


(function(){
  jQuery('.nectar-box-roll').click( function() {
    // alert('test')
    // jQuery('a.section-down-arrow').click();
    jQuery('.scroll-down-wrap .section-down-arrow')[0].click();
  });
})();
$(document).ready(function(){
     $('.errorMessage').hide();
   $('#mail').change(function(){
      var email = $('#mail').val();
      var testEmail = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
if (!testEmail.test(email)){
  $('.errorMessage').addClass('error');
}
else
{
        
   $('.errorMessage').removeClass('error');

}
      // if (email == '') {
      // console.log(email);
               
      //           $('#mail').keypress(function(){
      //               $('.errorMessage').removeClass('error');
      //           });
      //       }
    });
});
$(document).ready(function() {
  $('.errorMessage1').hide();
  $('#name').on('blur', function() {
      if( $(this).val() == ''  || $(this).val() == "null") {
            $('.errorMessage1').addClass('error');
      } else {
        $('.errorMessage1').removeClass('error');
              }
  })
});
$(document).ready(function() {
  $('.errorMessage2').hide();
  $('#phone_no').change(function(){
    var number = $('#phone_no').val();
    var testnumber = /\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/;
    if (!testnumber.test(number) || $(this).val() == ''  || $(this).val() == "null" ){
      $('.errorMessage2').addClass('error');
    }
    else {
            $('.errorMessage2').removeClass('error');    
    }
  // $('#phone_no').on('blur', function() {
  //     if( $(this).val() == ''  || $(this).val() == "null" || minlength:10 || maxlength:10) {
  //           $('.errorMessage2').addClass('error');
  //     } else {
  //       $('.errorMessage2').removeClass('error');
  //             }
  // })
});
});
$(document).ready(function() {
  $('.errorMessage3').hide();
  $('#msg').on('blur', function() {
      if( $(this).val() == ''  || $(this).val() == "null") {
            $('.errorMessage3').addClass('error');
      } else {
        $('.errorMessage3').removeClass('error');
              }
  })
});