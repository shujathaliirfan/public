<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;



require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
$name=$_POST['name'];
$email=$_POST['email'];
// $contact_no=$_POST['contact_no'];
$text_message=$_POST['message'];
// $expectations=$_POST['expectations'];


        
        // $email;$comment;$captcha;$name;$text_message;$contact_no;
        //  if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])){
        //      $secretKey = "6Le-7V4aAAAAAPcFCqg12BxvMw6kNcSEy8DmLoRb";
        //       $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secretKey.'&response='.$_POST['g-recaptcha-response']);
        //      $responseData = json_decode($verifyResponse);
        //      if($responseData->success){
        //          $name=$_POST['name'];
        //           $email=$_POST['email'];
        //           $text_message=$_POST['text_message'];
        //           $contact_no=$_POST['contact_no'];
        //      }
             
        //  }
         if(isset($_POST['name'])){
             
          $name=$_POST['name'];
         }
         if(isset($_POST['email'])){
          $email=$_POST['email'];
        }
        if(isset($_POST['message'])){
          $text_message=$_POST['message'];
        }
        // if(isset($_POST['contact_no'])){
            
        //   $contact_no=$_POST['contact_no'];
          
        // }
        // if(isset($_POST['comment'])){
        //   $email=$_POST['comment'];
        // }
        



        // $secretKey = "6Le-7V4aAAAAAPcFCqg12BxvMw6kNcSEy8DmLoRb";
        // $ip = $_SERVER['REMOTE_ADDR'];
       
        // $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
       
        // $response = file_get_contents($url);
         
        // $responseKeys = json_decode($response,true);
      
        

//         $msg="<head><style>
        
//         .ii a[href] {
//     color: white;
// }
//         tr td:nth-child(1) {
//     width: 20%;
// }
//         td{
//         padding: 10px;
//         border: 1px solid #000;
//         color: #000;
//         }
//         table{
//         border-collapse: collapse;
//         }
//         tr td:first-child {
//         background: #94001b;
//         color: #fff;
//         }
//         ul{
//         padding-left: 0;
//         margin: 0;
//         padding-bottom: 10px;
//         }
//         </style>
//         </head>
//         <table border='1' width='70%'>
//         <tr>
//         <td style='background: #94001b;color: #fff;'>Name</td>
//         <td style='background: #94001b;color: #fff;'>$name</td>
//         </tr>
        
//         <tr>
//         <td style='background: #94001b;color: #fff;'>Email</td>
//         <td style='background: #94001b;color: #fff;'>$email</td>
//         </tr>
//         <tr>
//         <td style='background: #94001b;color: #fff;'>Contact No</td>
//         <td style='background: #94001b;color: #fff;'>$contact_no</td>
//         </tr>
        
//         <tr>
//         <td style='background: #94001b;color: #fff;'>Message</td>
//         <td style='background: #94001b;color: #fff;'>$text_message</td>
//         </tr>";
        
//         $mail = new PHPMailer();
//         $mail->IsSMTP();
//         $mail->Mailer = "smtp";
//         $mail->SMTPDebug  = 0;  
//         $mail->SMTPAuth   = true;
//         $mail->CharSet   = "UTF-8";
//         $mail->SMTPSecure = "tls";
//         $mail->Port       = "587";
//         $mail->Host       =  'smtp.gmail.com';   
//         $mail->Username   = 'support@drillersdesk.com';
//         $mail->Password   = 'X(*Pgmy4'; 
//         $mail->IsHTML(true);
//         $mail->AddAddress("admin@drillersdesk.com", "admin");
//         $mail->AddAddress("monamohana1027@gmail.com", "priya");
//         $mail->SetFrom("support@drillersdesk.com", "Support");
//         $mail->Subject = "Contact Us";
//         $mail->MsgHTML($msg);
$message = '<table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="m_5275377665128817231bodyTable" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%;background-color:#e9eaec">
        <tbody><tr>
            <td align="center" valign="top" id="m_5275377665128817231bodyCell" style="height:100%;margin:0;padding:50px 50px;width:100%">
               

                <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_5275377665128817231templateContainer" style="border-collapse:collapse;border:0;max-width:600px!important">
                                            <tbody><tr>
                        <td valign="top" id="m_5275377665128817231templateBody" style="background-color:#ffffff;border-top:0;border:1px solid #c1c1c1;padding-top:0;padding-bottom:0px">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_5275377665128817231mcnTextBlock" style="min-width:100%;border-collapse:collapse">
                                <tbody class="m_5275377665128817231mcnTextBlockOuter">
                                    <tr>
                                        <td valign="top" class="m_5275377665128817231mcnTextBlockInner">
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_5275377665128817231mcnTextContentContainer">
                                                <tbody>
                                                    <tr>
                                                        <td valign="top" style="padding-top:30px;padding-right:30px;padding-bottom:30px;padding-left:30px" class="m_5275377665128817231mcnTextContent">
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Name</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$name.'</td>
    </tr>
    </tbody>
    </table>
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Email</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$email.'</td>
    </tr>
    </tbody>
    </table><span class="im">
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;width:100%">
    <tbody>
    <tr>
    <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Phone</strong></td>
    </tr>
    <tr>
    <td style="color:#555555;padding-top:3px;padding-bottom:20px">'.$contact_no.'</td>
    </tr>
    </tbody>
    </table>
    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #dddddd;display:block;min-width:100%;border-collapse:collapse;width:100%">
        <tbody>
        <tr>
        <td style="color:#333333;padding-top:20px;padding-bottom:3px"><strong>Message</strong></td>
        </tr>
        <tr>
        <td style="color:#555555;padding-top:3px;padding-bottom:20px text-align:justify;"><div style="text-align:justify;">'.$text_message.'</div></td>
        </tr>
        </tbody>
        </table>

   
                                                        </span></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" id="m_5275377665128817231templateFooter" style="background-color:#e9eaec;border-top:0;border-bottom:0;padding-top:12px;padding-bottom:12px">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_5275377665128817231mcnTextBlock" style="min-width:100%;border-collapse:collapse">
                                <tbody class="m_5275377665128817231mcnTextBlockOuter">
                                    <tr>
                                        <td valign="top" class="m_5275377665128817231mcnTextBlockInner">
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse" class="m_5275377665128817231mcnTextContentContainer">
                                                <tbody>
                                                    <tr>
                                                       
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody></table>
               

                </td>
            </tr>
        </tbody></table>';
    $to = "quwwtechnologies@gmail.com";
    $subject = "Contact Us";
    $txt = $message;
    $headers = 'From: shujathali92@gmail.com'. "\r\n";
    $headers .= 'Cc:aamirtariq01@gmail.com' . "\r\n";
    
    // To send HTML mail, the Content-type header must be set
    $headers  .= 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    // if($mail->send())
    if(mail($to,$subject,$txt,$headers))
        // if($mail->send())
        {
            // $_SESSION['sucess']="Enquiry Submitted Successfully";
            echo "<script>alert('Mail Send successfully')</script>"; 
        }
        else
        {
            echo "<script>alert('Mail Send un successfully')</script>"; 
        }
             
 


?>





        